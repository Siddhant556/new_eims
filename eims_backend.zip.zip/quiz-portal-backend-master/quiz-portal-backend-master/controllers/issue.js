const Issue = require("../models/issue");
const { errorHandler } = require("../helpers/dbErrorHandler");
const ObjectId = require('mongodb').ObjectID;

exports.create = (req, res) => {
    const issue = new Issue(req.body);
    issue.save((err, data) => {
        if (err) {
            return res.status(400).json({
                error: errorHandler(err)
            });
        }
        res.json({ data });
    });
};


exports.public_issue = (req, res) => {
    Issue.find().exec((err,data) => {
        if(err) {
            res.status(400).json({
                error: errorHandler(err)
            })
        }
        res.json(data);
    })
};

exports.private_issue_user = (req, res) => {
    Issue.find({"isPrivate":true,  "user": req.params.userId}).exec((err, data) => {
        if(err) {
            return res.status(400).json({
                error: errorHandler(err)
            })
        }
        return res.json(data);
    })
}

exports.private_issue_admin = (req, res) => {
    Issue.find({"isPrivate":true}).exec((err, data) => {
        if(err) {
            return res.status(400).json({
                error: errorHandler(err)
            })
        }
        return res.json(data);
    })
}

exports.update_status = (req, res) => {


 console.log(req.body.issueId, req.body.status);   

 Issue.findOneAndUpdate(
    {_id: req.body.issueId},
    {$set: {status: req.body.status, electrician: req.body.electricianId}},
    (err, issue) => {
        if(err) {
            return res.status(400).json({
                error: errorHandler(err)
            });
        }
        res.json(issue);
    }
 )   
}


// exports.update_status_electrician = (req, res) => {


//     console.log(req.body.issueId, req.body.status);   
   
//     Issue.findOneAndUpdate(
//        {_id: req.body.issueId},
//        {$set: {status: req.body.status}},
//        (err, issue) => {
//            if(err) {
//                return res.status(400).json({
//                    error: errorHandler(err)
//                });
//            }
//            res.json(issue);
//        }
//     )   
//    }
   
   

exports.assignedIssues = (req, res) => {
    Issue.find({"electrician":req.params.electricianId}).exec((err, data) => {
        if(err) {
            return res.status(400).json({
                error: errorHandler(err)
            })
        }
        return res.json(data);
    })
}


exports.deleteIssue = (req, res) => {
    Issue.deleteOne({_id:req.params.issueId}).exec((err, data) => {
        if(err) {
            return res.status(400).json({
                error: errorHandler(err)
            })
        }
        return res.json(data);
    })
}
