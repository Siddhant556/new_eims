const Electrician = require("../models/electrician");
const { errorHandler } = require("../helpers/dbErrorHandler");
const ObjectId = require('mongodb').ObjectID;
const crypto = require("crypto");
const uuidv1 = require("uuid/v1");

exports.create = (req, res) => {
    const electrician = new Electrician(req.body);
    electrician.save((err, data) => {
        if (err) {
            return res.status(400).json({
                error: errorHandler(err)
            });
        }
        res.json({ data });
    });
};


exports.list = (req, res) => {
    Electrician.find().exec((err,data) => {
        if(err) {
            res.status(400).json({
                error: errorHandler(err)
            })
        }
        res.json(data);
    })
};

exports.update = (req, res) => {


    // console.log(req.body.issueId, req.body.status);   
   
    Electrician.findOneAndUpdate(
       {_id: req.body.electricianId},
       {$set: {applicationStatus: req.body.status}},
       (err, issue) => {
           if(err) {
               return res.status(400).json({
                   error: errorHandler(err)
               });
           }
           res.json(issue);
       }
    )   
   }