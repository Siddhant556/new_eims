const express = require("express");
const router = express.Router();

const {
    create, list, update
} = require("../controllers/electrician");

const { requireSignin, isAuth, isAdmin } = require("../controllers/auth");
const { userById } = require("../controllers/user");

router.post("/create",  create);
router.get("/list", list);
router.put("/update", update);

module.exports = router;
