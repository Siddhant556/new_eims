const express = require("express");
const router = express.Router();

const {
    create, public_issue, private_issue_user, private_issue_admin, update_status, assignedIssues, update_status_electrician, deleteIssue
} = require("../controllers/issue");

const { requireSignin, isAuth, isAdmin } = require("../controllers/auth");
const { userById } = require("../controllers/user");

router.post("/create", create);
router.get("/public_issue", public_issue);
router.get("/private_issue_user/:userId", private_issue_user);
router.get("/private_issue_admin", private_issue_admin);
router.get("/assigned_issues/:electricianId", assignedIssues);
router.put("/update_status", update_status);
router.delete("/delete/:issueId", deleteIssue);
// router.put("/update_status_electrician", update_status_electrician);

module.exports = router;
