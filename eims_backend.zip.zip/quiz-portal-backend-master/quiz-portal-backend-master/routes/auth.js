const express = require("express");
const router = express.Router();

const {
    signup,
    signin,
    signout,
    requireSignin,
    electricianSignIn
} = require("../controllers/auth");
const { userSignupValidator } = require("../validator");

router.post("/signup", signup);
router.post("/signin", signin);
router.get("/signout", signout);
router.post("/electrician_sign_in", electricianSignIn);

module.exports = router;
