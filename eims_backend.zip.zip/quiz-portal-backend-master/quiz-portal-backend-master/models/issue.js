const mongoose = require('mongoose');


const issueSchema = new mongoose.Schema({
    fName: {
        type: String,
        required: true
    },
    lName: {
        type: String,
    },
    contactNo: {
        type: String,
    },
    state: {
        type: String,
    },
    city: {
        type: String,
    },
    address: {
        type: String,
    },
    title: {
        type: String
    },
    details:{
        type: String
    },
    isPrivate: {
        type: Boolean,
        default: false
    },
    status:{
        type: String,
        default: "Pending",
        enum: ['Pending', 'Assigned to Electrician', 'Resolved', 'Rejected']
    },
    electrician: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Electrician"
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    }
},
    {timestamps: true}
)

module.exports = mongoose.model("Issue", issueSchema)